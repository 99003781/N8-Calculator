# Binary Conversions
The UML Diagrams are for Low Level Binary Conversion feature of Calculator
 - The calculator takes decimal integer as input and converts it into hex and binary
 - The calculator takes binary as input and converts it into hex and decimal
 - Only positive integers are allowed as input
 - Input range is size of word
 - Binary output range is size of word. Gives error or wrong value for output exceeding word. 