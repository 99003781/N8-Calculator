#include<stdio.h>
#include<math.h>
#include<stdlib.h>

void trig_choose();

double sine(double angle_value_degrees);
double cosine(double angle_value_degrees);
double tangent(double angle_value_degrees);
double cot(double angle_value_degrees);
double sec(double angle_value_degrees);
double cosec(double angle_value_degrees);

