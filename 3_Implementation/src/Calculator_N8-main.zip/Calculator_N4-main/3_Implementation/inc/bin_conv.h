#include<stdio.h>
#include<math.h>
#include<stdlib.h>
long dectobin();
long dectohexa(long quotient);
long decimaltobin(long binary);
long binarytodec(long  bintodec_val);
long binarytohex(long  bintohex_val);

