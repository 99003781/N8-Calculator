#include<stdio.h>
void dim_con();
