#include<stdio.h>
void basics();
float add(float a,float b);
float sub(float c,float d);
float mul(float e,float f);
float divd(float g,float h);
int remb(int i, int j);
